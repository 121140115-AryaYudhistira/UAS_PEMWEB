<?php
$dbhost = "localhost";
$dbuser = "id21680358_aryayudhistira";
$dbpass = "Smartfren123!";
$db = "id21680358_barokah";
$conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n" . $conn->error);
